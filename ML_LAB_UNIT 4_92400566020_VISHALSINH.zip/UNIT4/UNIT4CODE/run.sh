for practical in {1..9}
do 
echo "Running Practical ${practical}"
python "practical_${practical}.py"
done