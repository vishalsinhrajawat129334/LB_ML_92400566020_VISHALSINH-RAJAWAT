import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# data
data = pd.read_csv('student_marks.csv')

# features and target variable
X = data[["Mark1", "Mark2"]]
y = data["Admitted"]

# split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# model
model = LogisticRegression()
model.fit(X_train, y_train)

# predict 
y_pred = model.predict(X_test)

# accuracy
print("Accuracy:", accuracy_score(y_test, y_pred) * 100, "%")