for prog in {1..6}
do
echo "Program number ${prog}"
python "prog${prog}.py"
done