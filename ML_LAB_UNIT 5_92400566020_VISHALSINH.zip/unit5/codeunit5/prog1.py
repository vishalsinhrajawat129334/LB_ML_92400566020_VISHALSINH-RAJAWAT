import pandas as pd
from sklearn.linear_model import LinearRegression

# Read CSV file
ds = pd.read_csv("cputime.csv")

X = ds[["DiskIO"]]
y = ds["CPUTime"]


model = LinearRegression()


model.fit(X, y)

# DiskIO = 40
prediction = model.predict([[40]])

print("Predicted CPU Time:", prediction[0])